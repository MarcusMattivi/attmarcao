import React from 'react'
import {
    View,
    Text, 
    StyleSheet, 
    Image, 
    TouchableOpacity,
    TextInput
   } from 'react-native'

import * as Animatable from 'react-native-animatable'

import { useNavigation } from '@react-navigation/native'

export default function Welcome(){
    const navigation = useNavigation()
    return(
      <View style={styles.container} >
        <View style={styles.containerLogo}>
          <Animatable.Image 
            animation='flipInY'
            source={require('../../assets/organizeMe.png')}
            style= {{ width: '100%' }}
            resizeMode='contain'
          />
        </View>
  
        <Animatable.View delay={600} animation='fadeInUp' style={styles.containerForm}>
          <Text style={styles.title}>Planner para facilitar sua vida</Text>
          <Text style={styles.text}>Acesse e faça o login</Text>
  
          <TouchableOpacity 
            style={ styles.button}
            onPress={ () => navigation.navigate('signin')}
          >
            <Text style={styles.buttonText}>Acessar</Text>
          </TouchableOpacity>
        </Animatable.View>
      </View> 
    );
  }
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#993399'
    },
    containerLogo: {
      flex: 2,
      backgroundColor: '#993399',
      justifyContent: 'center',
      alignItems: 'center'
    },
    containerForm: {
      flex: 1,
      backgroundColor: '#fff',
      borderTopLeftRadius: 25,
      borderTopRightRadius: 25,
      paddingStart: '5%',
      paddingEnd: '5%'
    },
    title: {
      fontSize: 24,
      fontWeight: 'bold',
      marginTop: 28,
      marginBottom: 12,
      textAlign: 'center'
    },
    text: {
      color: '#a1a1a1',
      fontSize: 20,
      textAlign: 'center'
    },
    button: {
      position: 'absolute',
      backgroundColor: '#993399',
      borderRadius: 50,
      paddingVertical: 8,
      width: '60%',
      alignSelf: 'center',
      bottom: '15%',
      alignItems: 'center',
      justifyContent: 'center'
    },
    buttonText: {
      fontSize: 18,
      color: '#fff',
      fontWeight: 'bold'
    },
    input:{
      borderBottomWidth: 1,
      height: 40,
      marginBottom: 12,
      fontSize: 16
    }
  })