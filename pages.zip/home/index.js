import React from 'react'
import {
    View,
    Text, 
    StyleSheet, 
    Image, 
    TouchableOpacity,
    StatusBar
   } from 'react-native'

import * as Animatable from 'react-native-animatable'

import { useNavigation } from '@react-navigation/native'

export default function Home() {
  const navigation = useNavigation()
  return (
    <View style={styles.container}>
      <View style={styles.containerHeader}>
     <Text style={styles.messagem}>organizeMe</Text>
      </View>
      <View style={styles.containerForm}>

        <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Agenda</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Lista de Tarefas</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Metas</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Gastos</Text>
        </TouchableOpacity>

      <TouchableOpacity style={styles.buttonPerfil}
      onPress={() => navigation.navigate('perfil')}
      >
        <Text style={styles.textPerfil}>Ver perfil</Text>
      </TouchableOpacity>

      </View>
      <StatusBar style="auto" />
    </View>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#993399'
  },
  containerHeader: {
    marginBottom: '2%',
    paddingStart: '5%',
  },
  messagem: {
    fontSize: 40,
    marginTop: '10%',
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: '5%'
  },
  containerForm:{
    backgroundColor: '#fff',
    flex: 1,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    paddingStart: '10%',
    paddingEnd: '10%'
  },
  tittle: {
    fontSize: 20,
    marginTop: 28
  },
  button: {
    backgroundColor: '#993399',
    widht: '100%',
    borderRadius:7,
    paddingVertical: 6,
    marginTop: 17,
    justifyContent: 'center',
    alignItems: 'center'
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 30
  },
  textPerfil: {
    fontSize: 30,
    color: '#fff',
    fontWeight: 'bold'
  },
  buttonPerfil: {
    backgroundColor: '#993399',
    widht: '100%',
    borderRadius:7,
    paddingVertical: 5,
    marginTop: 200,
    justifyContent: 'center',
    alignItems: 'center'
  }
  });
