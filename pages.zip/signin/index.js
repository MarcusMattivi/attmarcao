import React from 'react'
import {
    View,
    Text, 
    StyleSheet, 
    Image, 
    TouchableOpacity,
    TextInput,
    StatusBar
   } from 'react-native'

import { useNavigation } from '@react-navigation/native'

export default function Signin() {
  const navigation = useNavigation()
  return (
    <View style={styles.container}>
      <View style={styles.containerHeader}>
        <Text style={styles.message}>Bem Vindo(a) crie sua conta abaixo!</Text>
      </View>
      <View style={styles.containerForm}>
      <Text style={styles.tittle}>Email</Text>
      <TextInput style={styles.input}/>
      <Text style={styles.tittle}>Senha</Text>
      <TextInput style={styles.input}/>

      <TouchableOpacity 
            style={ styles.button}
            onPress={ () => navigation.navigate('home')}
          >
        <Text style={styles.buttonText}>Fazer Login</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={()=> navigation.navigate('register')} style={styles.buttonRegister}>
        <Text style={styles.textRegister}>Esqueceu a senha?</Text>
      </TouchableOpacity>
      </View>
      <StatusBar style="auto" />
    </View>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#993399',
  },
  containerHeader: {
    marginTop: '15%',
    marginBottom: '8%',
    paddingStart: '5%',
  },
  message: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    paddingEnd: '5%'
  },
  containerForm:{
    backgroundColor: '#fff',
    flex: 1,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    paddingStart: '5%',
    paddingEnd: '5%'
  },
  tittle: {
    fontSize: 20,
    marginTop: 28
  },
  input:{
    borderBottomWidth: 1,
    height: 40,
    marginBottom: 12,
    fontSize: 16
  },
  button: {
    backgroundColor: '#993399',
    widht: '100%',
    borderRadius:4,
    paddingVertical: 8,
    marginTop: 14,
    justifyContent: 'center',
    alignItems: 'center'
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold'
  },
  buttomRegister: {
    marginTop: 14,
    alignItems: 'center'
  },
  textRegister: {
    color: '#a1a1a1'
  }
  });
