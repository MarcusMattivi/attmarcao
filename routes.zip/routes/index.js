import { createNativeStackNavigator } from '@react-navigation/native-stack'

import Welcome from '../pages/welcome'
import Signin from '../pages/signin'
import Register from '../pages/register'
import Home from '../pages/home'
import Perfil from '../pages/perfil'

const Stack = createNativeStackNavigator();

export default function Routes() {
    return (
        <Stack.Navigator>
            <Stack.Screen
            name="welcome"
            component= { Welcome }
            options= { {headerShown: false}}
            />
            <Stack.Screen
            name="signin"
            component= { Signin }
            options= { {headerShown: false} }
            />
              <Stack.Screen
            name="register"
            component= { Register }
            options= { {headerShown: false} }
            />
             <Stack.Screen
            name="home"
            component= { Home }
            options= { {headerShown: false} }
            />
            <Stack.Screen
            name="perfil"
            component= { Perfil }
            options= { {headerShown: false} }
            />
        </Stack.Navigator>
    )
}